package LWP::DebugFile;

our $VERSION = '6.81';

# legacy stub

1;
