package URI::scp;

use strict;
use warnings;

our $VERSION = '5.34';

use parent 'URI::ssh';

1;
