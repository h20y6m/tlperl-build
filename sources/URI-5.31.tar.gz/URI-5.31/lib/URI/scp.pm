package URI::scp;

use strict;
use warnings;

our $VERSION = '5.31';

use parent 'URI::ssh';

1;
